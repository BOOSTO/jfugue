import org.jfugue.player.Player;

public class Main {
    public static void main(String[] args) {
        Player p = new Player();
        p.play("C D E");
    }
}
